---
name: T2M Professional Neutral
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#42474d'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#73777e'
  outline-variant: '#c3c7ce'
  surface-tint: '#406182'
  primary: '#001629'
  on-primary: '#ffffff'
  primary-container: '#002b49'
  on-primary-container: '#7293b6'
  inverse-primary: '#a8caef'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e4e2e1'
  on-secondary-container: '#656464'
  tertiary: '#131515'
  on-tertiary: '#ffffff'
  tertiary-container: '#272929'
  on-tertiary-container: '#8f9090'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cfe5ff'
  primary-fixed-dim: '#a8caef'
  on-primary-fixed: '#001d34'
  on-primary-fixed-variant: '#274969'
  secondary-fixed: '#e4e2e1'
  secondary-fixed-dim: '#c8c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style
The design system is engineered for utility, clarity, and authority. It targets professional environments where information density must be balanced with extreme readability. The aesthetic is **Minimalist and Sophisticated**, leaning into a corporate-modern movement that prioritizes functional elegance over decorative trends.

The brand personality is "Quietly Confident"—it does not shout for attention but provides a high-contrast, structured environment that facilitates focus. By utilizing a restrained palette and sharp execution, the UI evokes a sense of reliability and institutional stability.

## Colors
The palette is rooted in high-contrast neutrality to ensure WCAG AA accessibility standards are met effortlessly. 

- **Primary (Deep Anchor Blue):** Reserved for high-impact touchpoints including primary CTAs, brand iconography, and major section headings. It serves as the "anchor" of the visual hierarchy.
- **Secondary (Dark Grey):** Used for all primary body copy and sub-navigation elements to reduce eye strain compared to pure black.
- **Surface (Light Grey):** Applied to card backgrounds, input fields, and structural containers to subtly differentiate content zones from the main page.
- **Background (Pure White):** The base canvas for all views, providing a clean, expansive feel that emphasizes the minimalist style.

## Typography
This design system exclusively employs **Inter**, utilizing its systematic, utilitarian nature to drive the interface. The type scale is built on a tight ratio to maintain a professional, news-like density.

Large headings use tighter letter spacing and heavier weights in Deep Anchor Blue. Body text is set in Dark Grey with generous line heights (1.6x) to ensure legibility in data-heavy views. Labels and small metadata should utilize the `label-md` style with uppercase transformations to provide clear visual distinction from body prose.

## Layout & Spacing
The system utilizes a **Fixed Grid** model for desktop and a fluid model for mobile. 

- **Desktop:** A 12-column grid centered within a 1280px container.
- **Mobile:** A 4-column fluid grid with 16px side margins.

The spacing rhythm is based on an 8px square grid. Internal component spacing (padding) should primarily use the `sm` (12px) and `md` (24px) units to maintain a "breathable" but compact professional aesthetic. Section-to-section vertical spacing should default to `xl` (64px) to emphasize the minimalist use of whitespace.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** rather than heavy shadows. The system is intentionally "flat-plus," using color and subtle borders to define hierarchy.

- **Level 0 (Background):** Pure White.
- **Level 1 (Surface):** Light Grey containers are used to group related content.
- **Level 2 (Interactive):** Elements that require focus (like active cards) use a 1px solid border in Light Grey or a very subtle, highly diffused 5% opacity Anchor Blue shadow.
- **Focus States:** High-visibility 2px solid strokes in Deep Anchor Blue to ensure keyboard navigation clarity.

## Shapes
The shape language is **Soft**. To maintain a professional and serious tone, the system avoids large radii. A consistent 4px (0.25rem) radius is applied to buttons, input fields, and small UI components. Larger containers like cards may scale up to 8px (0.5rem), but should never appear "bubbly." Precision and clean lines are the priority.

## Components
- **Buttons:** Primary buttons are solid Deep Anchor Blue with White text. Secondary buttons are ghost-style with a Dark Grey 1px border. All buttons use the `label-md` type style.
- **Input Fields:** Backgrounds should be Light Grey with a bottom-border-only or a subtle 1px frame in a medium-grey shade. Labels must sit clearly above the field in `body-sm` bold.
- **Cards:** Use the Light Grey surface with no border and no shadow to define the area. Padding within cards should be a consistent 24px (`md`).
- **Chips/Tags:** Small, rectangular shapes with 2px radius. Use Light Grey backgrounds with Dark Grey text for neutral tags, and Deep Anchor Blue backgrounds for active filters.
- **Lists:** Clean, horizontal dividers using 1px Light Grey lines. Avoid icons unless they provide immediate functional value.
- **Data Tables:** High-density, no vertical lines, 1px horizontal dividers. Header row should be Light Grey with `label-md` typography.
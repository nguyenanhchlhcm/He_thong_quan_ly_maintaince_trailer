---
name: T2M-App Design System
colors:
  surface: '#fff8f5'
  surface-dim: '#e7d7ce'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1e9'
  surface-container: '#fbebe1'
  surface-container-high: '#f5e5dc'
  surface-container-highest: '#efe0d6'
  on-surface: '#221a14'
  on-surface-variant: '#544438'
  inverse-surface: '#382f28'
  inverse-on-surface: '#feeee4'
  outline: '#867366'
  outline-variant: '#d9c2b3'
  surface-tint: '#904d00'
  primary: '#904d00'
  on-primary: '#ffffff'
  primary-container: '#f2994a'
  on-primary-container: '#663500'
  inverse-primary: '#ffb77d'
  secondary: '#545e76'
  on-secondary: '#ffffff'
  secondary-container: '#d7e2ff'
  on-secondary-container: '#5a647c'
  tertiary: '#5d5f5c'
  on-tertiary: '#ffffff'
  tertiary-container: '#adaeab'
  on-tertiary-container: '#40423f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcc3'
  primary-fixed-dim: '#ffb77d'
  on-primary-fixed: '#2f1500'
  on-primary-fixed-variant: '#6e3900'
  secondary-fixed: '#d7e2ff'
  secondary-fixed-dim: '#bbc6e2'
  on-secondary-fixed: '#101b30'
  on-secondary-fixed-variant: '#3c475d'
  tertiary-fixed: '#e2e3df'
  tertiary-fixed-dim: '#c6c7c3'
  on-tertiary-fixed: '#1a1c1a'
  on-tertiary-fixed-variant: '#454745'
  background: '#fff8f5'
  on-background: '#221a14'
  surface-variant: '#efe0d6'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  touch-target-min: 48px
  unit: 8px
  gutter: 16px
  margin-mobile: 16px
  margin-tablet: 24px
  stack-gap: 12px
---

## Brand & Style

This design system is built for the high-intensity, physical environment of truck and trailer maintenance. The brand personality is **Reliable, Rugged, and Error-Proof**. It balances industrial professionalism with an approachable "non-tech" friendliness to ensure mechanics feel confident using the tool regardless of their digital literacy.

The visual direction follows a **Poka-yoke (Error-Prevention)** philosophy. This is achieved through a **High-Contrast / Tactile** style that prioritizes clarity over decoration. Surfaces are distinct, actions are unmistakable, and the UI is optimized for "heavy-handed" interaction—accommodating users who may be wearing gloves or working in low-light garages. The emotional response should be one of utility and "it just works."

## Colors

The palette is rooted in industrial safety and professional reliability.

- **Primary (Safety Orange):** Used exclusively for primary actions (CTA) and critical highlights. It stands out against the navy background to draw the eye immediately to the next logical step in a workflow.
- **Secondary (Deep Navy):** Provides a professional, "heavy-duty" foundation. It is used for headers, navigation, and primary text to ensure maximum legibility.
- **Status Colors:** High-saturation Green and Red are used for "Pass/Fail" inspections. These colors are paired with icons to ensure accessibility for color-blind users.
- **Neutral (Slate/Light Grey):** Used for background surfaces and secondary containers to keep the interface clean and reduce visual noise in complex forms.

## Typography

This design system utilizes **Inter** for its exceptional legibility and neutral, functional tone. The type scale is intentionally larger than standard consumer apps to accommodate quick scanning in high-activity environments.

- **Vietnamese Language Support:** All levels are optimized for Vietnamese diacritics, ensuring no clipping of tone marks occurs.
- **Emphasis:** Bold weights are used frequently for equipment IDs, plate numbers (Biển số), and status indicators (Trạng thái) to ensure critical data points are never missed.
- **Body Text:** A minimum of 16px is maintained for all functional text to ensure readability on mobile devices at arm's length.

## Layout & Spacing

The layout philosophy centers on a **Fluid Grid** with generous padding to prevent accidental taps. 

- **8pt Grid System:** All dimensions, padding, and margins are multiples of 8px.
- **Touch Targets:** A strict minimum touch target of 48x48px is enforced for all interactive elements. For high-frequency actions like "Bắt đầu bảo trì" (Start Maintenance), targets are expanded to 64px height.
- **Mobile-First:** The primary interface is a single-column vertical stack to simplify navigation for users holding a device in one hand.
- **Content Reflow:** On tablets, the layout shifts to a 2-column "Master-Detail" view to keep context visible while filling out inspection forms.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and **Low-Contrast Outlines** rather than complex shadows. This keeps the UI feeling "flat" and modern while clearly separating interactive cards from the background.

- **Cards:** Use a 1px border (#E0E1DD) and a very subtle ambient shadow (4px blur, 4% opacity) to appear slightly lifted above the light-grey background.
- **Active State:** When a card or input is focused, the border thickness increases to 2px using the Primary color (Safety Orange), providing unmistakable feedback.
- **Depth:** Modal overlays use a 40% opacity navy backdrop to isolate the task at hand and minimize distractions.

## Shapes

The design system uses a **Rounded** (Level 2) shape language.

- **Standard Elements:** 8px (0.5rem) radius for buttons and input fields, providing a friendly yet professional feel.
- **Cards & Containers:** 16px (1rem) radius for major sections (e.g., Vehicle Info cards) to create a distinct containerized look.
- **Status Badges:** Use a "Pill-shape" (full rounding) to differentiate them from interactive buttons.

## Components

The components are designed for high-stress, real-world utility.

- **Large Buttons:** Primary buttons are full-width on mobile with a minimum height of 56px. Labeling is direct (e.g., "HOÀN THÀNH" vs "Xong").
- **Inspection Cards:** Large cards containing a title, a plate number, and a high-contrast status badge. The entire card is a touch target.
- **Offline-Status Indicator:** A persistent bar at the top of the screen (Navy or Amber) that clearly states "Đang ngoại tuyến - Dữ liệu sẽ đồng bộ sau" (Offline - Data will sync later).
- **Simple Form Inputs:** Inputs feature large text labels above the field (not as placeholders) to ensure the user never loses context. Stepper inputs ( + / - ) are used for quantities to avoid the need for the keyboard where possible.
- **Pass/Fail Toggles:** Large, side-by-side buttons for inspections. "Đạt" (Pass) in Green, "Không đạt" (Fail) in Red. When selected, the color fills the button; when unselected, it remains a ghost border.
- **Photo Uploaders:** A prominent camera icon button with the label "Chụp ảnh minh chứng" (Take proof photo) to facilitate rapid documentation of defects.
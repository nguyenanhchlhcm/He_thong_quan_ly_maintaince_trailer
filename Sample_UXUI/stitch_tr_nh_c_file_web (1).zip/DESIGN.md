---
name: Analogous Harmony
colors:
  surface: '#faf9fd'
  surface-dim: '#dad9dd'
  surface-bright: '#faf9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f7'
  surface-container: '#eeedf1'
  surface-container-high: '#e9e7ec'
  surface-container-highest: '#e3e2e6'
  on-surface: '#1a1b1f'
  on-surface-variant: '#43474e'
  inverse-surface: '#2f3033'
  inverse-on-surface: '#f1f0f4'
  outline: '#74777f'
  outline-variant: '#c4c6d0'
  surface-tint: '#455f8a'
  primary: '#000e24'
  on-primary: '#ffffff'
  primary-container: '#00234b'
  on-primary-container: '#718bb9'
  inverse-primary: '#adc7f8'
  secondary: '#1c648e'
  on-secondary: '#ffffff'
  secondary-container: '#90cdfd'
  on-secondary-container: '#025881'
  tertiary: '#1e0700'
  on-tertiary: '#ffffff'
  tertiary-container: '#401700'
  on-tertiary-container: '#bc7b58'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f8'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#2c4771'
  secondary-fixed: '#cae6ff'
  secondary-fixed-dim: '#90cdfd'
  on-secondary-fixed: '#001e30'
  on-secondary-fixed-variant: '#004b70'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb690'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#6c391c'
  background: '#faf9fd'
  on-background: '#1a1b1f'
  surface-variant: '#e3e2e6'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

This design system is built for the rugged yet precision-oriented world of fleet logistics. The brand personality is **authoritative, dependable, and forward-thinking**. It balances the heavy-duty nature of trucking with a "fresh" digital experience that feels high-tech and organized.

The design style follows a **Modern Corporate** aesthetic. It prioritizes clarity and efficiency, utilizing a minimalist approach with generous white space to reduce cognitive load for drivers and fleet managers. The visual language relies on a "safety-first" hierarchy, where structural integrity is represented by deep tones and progress is highlighted through vibrant accents. The emotional goal is to instill confidence that the user's vehicle and data are in expert hands.

## Colors

The palette uses a hierarchical structure to ensure "Analogous Harmony" between heavy-duty utility and modern software:

*   **Primary (Deep Navy Blue):** Used for global headers, primary action buttons, and critical branding. It provides the "anchor" for the UI, suggesting stability.
*   **Secondary (Light Blue):** Applied to informative elements like progress bars, informational icons, and the background of card containers. It softens the interface.
*   **Accent (Teal/Cyan):** Reserved for "success" states, sustainability metrics, and secondary interactive links. This color symbolizes the "green light" for a vehicle's health.
*   **Backgrounds:** A crisp White is used for content surfaces, while a Light Gray (Cool Slate) is used for the base application background to provide subtle contrast between cards.

## Typography

The system utilizes **Inter** for its exceptional legibility at small sizes—crucial for data-heavy maintenance logs and mobile-first driver tools.

*   **Headlines:** Use Bold and Semi-Bold weights in Deep Navy to establish clear section breaks.
*   **Body:** Regular weight for maximum readability. Use Body-MD for general descriptions and Body-LG for key instructional text.
*   **Labels:** Use the uppercase Bold label style for technical specs (e.g., VIN, Odometer labels) to differentiate static data from dynamic user input.
*   **Scale:** On mobile devices, large display headlines should downscale to the `headline-lg-mobile` token to prevent excessive wrapping.

## Layout & Spacing

The layout philosophy follows a **4px baseline grid** to ensure mathematical consistency across all components.

*   **Grid System:** A 12-column fluid grid for desktop and a 4-column fluid grid for mobile.
*   **Margins & Gutters:** Mobile views use 16px side margins. Desktop views expand to 48px margins with a maximum content width of 1440px to maintain readability.
*   **Vertical Rhythm:** Use the `md (16px)` spacing unit for most gaps between related elements. Use `lg (24px)` to separate distinct content blocks or card groups.

## Elevation & Depth

This design system uses a **Tonal Layering** approach supplemented by **Ambient Shadows**.

*   **Surface Hierarchy:** The base background is the lowest layer (Neutral Background). Information is contained in White "Surfaces" (Cards).
*   **Shadows:** Shadows are highly diffused and low-opacity (5-10% alpha) using the Deep Navy color as the shadow tint. This avoids "muddy" grays and keeps the UI looking fresh.
*   **Depth Levels:** 
    *   *Level 0:* Flat (Base background).
    *   *Level 1:* 2px blur, 1px offset (Cards, toggle buttons).
    *   *Level 2:* 8px blur, 4px offset (Modals, dropdown menus, active floating action buttons).

## Shapes

The shape language is defined as **Moderate (Rounded)**. All primary containers and buttons utilize a standard **8px (0.5rem)** corner radius. 

*   **Buttons & Inputs:** Consistent 8px radius.
*   **Cards:** 16px (rounded-lg) for large dashboard containers to create a softer, more modern feel.
*   **Indicators:** Status badges and small "pill" tags use a fully rounded (999px) radius to distinguish them from interactive buttons.

## Components

*   **Primary Buttons:** Deep Navy background with White text. Use 16px vertical padding. No borders.
*   **Secondary Actions:** Outlined buttons using the Teal/Cyan accent color or Light Blue for less critical actions.
*   **Information Cards:** White background with an 8px radius and a Level 1 shadow. Headers within cards should have a subtle Light Blue bottom border.
*   **Inputs:** Light Gray stroke (1px). On focus, the stroke changes to Deep Navy with a 2px Light Blue outer glow (soft shadow).
*   **Status Indicators:** Small dots or chips using Teal for "Healthy," Amber for "Service Due," and Red for "Critical."
*   **Maintenance Lists:** Alternating row highlights are not used; instead, use 8px spacing between list items, with each item acting as a subtle "mini-card."
*   **Vehicle Health Gauges:** Use the Secondary Light Blue for the "track" and the Accent Teal for the "progress" indicator.